module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  "plugins": [
    "@babel/plugin-syntax-dynamic-import"
    ],
    sourceType: 'unambiguous'
}
