package com.github.niefy.modules.wx.service;

import com.github.niefy.modules.wx.dto.UserInfoDto;
import com.github.niefy.modules.wx.param.UserInfoParam;

public interface WechatUserInfoService {

    UserInfoDto findByIdentity(UserInfoParam userInfoParam);

}
