package com.github.niefy.modules.wx.handler;

import com.alibaba.fastjson.JSONObject;
import com.github.niefy.common.utils.BeanCopyUtils;
import com.github.niefy.modules.wx.dto.WxTemplateResponse;
import com.github.niefy.modules.wx.entity.TemplateMsgLog;
import com.github.niefy.modules.wx.service.TemplateMsgLogService;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.common.session.WxSessionManager;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.bean.message.WxMpXmlMessage;
import me.chanjar.weixin.mp.bean.message.WxMpXmlOutMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;

/**
 * 处理模板消息发送结果的逻辑
 *  wxMessage字段可见 https://developers.weixin.qq.com/doc/offiaccount/Message_Management/Template_Message_Interface.html
 */

@Component
@Slf4j
public class TemplateSendFinishHandler extends AbstractHandler{

    @Autowired
    private TemplateMsgLogService templateMsgLogService;

    @Override
    public WxMpXmlOutMessage handle(WxMpXmlMessage wxMessage,
                                    Map<String, Object> context, WxMpService wxMpService,
                                    WxSessionManager sessionManager) throws WxErrorException {
        log.info("接收到微信回调消息+"+JSONObject.toJSONString(wxMessage));
        String status = wxMessage.getStatus();
        String msgId = Objects.nonNull(wxMessage.getMsgId())? String.valueOf(wxMessage.getMsgId()) : "";
        //将微信返回的转化为自己封装的对象
        WxTemplateResponse response = BeanCopyUtils.copy(wxMessage, WxTemplateResponse.class);

        //保存状态以及报文
        TemplateMsgLog templateMsgLog = new TemplateMsgLog();
        templateMsgLog.setMsgId(msgId);
        templateMsgLog.setStatus(status);
        templateMsgLog.setResponse(JSONObject.toJSONString(response));
        templateMsgLogService.updateTemplateMsgLogStatus(templateMsgLog);
        log.info("msgId-{0}对应的状态已更新" + msgId);

        return null;
    }
}
