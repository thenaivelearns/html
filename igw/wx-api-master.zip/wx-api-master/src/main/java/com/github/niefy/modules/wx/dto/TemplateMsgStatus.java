package com.github.niefy.modules.wx.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TemplateMsgStatus {

    private String msgId;

    private String status;
}
