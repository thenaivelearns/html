package com.github.niefy.modules.wx.service;

import com.github.niefy.common.utils.Result;
import com.github.niefy.modules.wx.dto.TemplateMsgResult;
import com.github.niefy.modules.wx.form.TemplateMsgBatchForm;
import me.chanjar.weixin.mp.bean.template.WxMpTemplateMessage;

public interface TemplateMsgService {
    /**
     * 发送微信模版消息
     */
    void sendTemplateMsg(WxMpTemplateMessage msg,String appid);

    /**
     * 批量消息发送
     * @param form
     * @param appid
     */
    void sendMsgBatch(TemplateMsgBatchForm form,String appid);

    /**
     * 同步发送消息
     * @param msg 消息参数
     * @param appid 公众号id
     * @Return 成功返回msgId 失败返回错误信息
     */
    Result<TemplateMsgResult> syncSendTemplateMsg(WxMpTemplateMessage msg, String appid);
}
