package com.github.niefy.modules.wx.service.impl;

import com.github.niefy.common.exception.RRException;
import com.github.niefy.modules.wx.dao.DeriveTemplateMapper;
import com.github.niefy.modules.wx.dto.TemplateInfo;
import com.github.niefy.modules.wx.param.TemplateSearchParam;
import com.github.niefy.modules.wx.service.DeriveTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class DeriveTemplateServiceImpl implements DeriveTemplateService {

    @Autowired
    private DeriveTemplateMapper deriveTemplateMapper;

    @Override
    public TemplateInfo findByDeriveTemplateId(String deriveTemplateId) {
        TemplateInfo templateInfo = deriveTemplateMapper.findByDeriveTemplateId(deriveTemplateId);

        if (Objects.isNull(templateInfo)){
            throw new RRException("找不到此templateId对应的衍生模板");
        }

        if (!"1".equals(templateInfo.getStatus())){
            throw new RRException("此模板已禁用，请联系管理员");
        }

        return templateInfo;
    }

    @Override
    public List<TemplateInfo> getDeriveTemplate(TemplateSearchParam templateParam) {

        return deriveTemplateMapper.findDeriveTemplateList(templateParam);
    }
}
