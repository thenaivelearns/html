package com.github.niefy.modules.wx.dao;

import com.github.niefy.modules.wx.dto.TemplateInfo;
import com.github.niefy.modules.wx.param.TemplateSearchParam;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DeriveTemplateMapper {

    TemplateInfo findByDeriveTemplateId(@Param("deriveTemplateId") String deriveTemplateId);

    List<TemplateInfo> findDeriveTemplateList(@Param("template")TemplateSearchParam param);
}
