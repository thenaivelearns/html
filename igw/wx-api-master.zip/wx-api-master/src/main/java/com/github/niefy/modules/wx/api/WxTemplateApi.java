package com.github.niefy.modules.wx.api;

import com.alibaba.fastjson.JSONObject;
import com.github.niefy.common.utils.Result;
import com.github.niefy.modules.wx.dto.*;
import com.github.niefy.modules.wx.param.BatchBusinessMsgParam;
import com.github.niefy.modules.wx.param.BusinessMsgParam;
import com.github.niefy.modules.wx.param.TemplateSearchParam;
import com.github.niefy.modules.wx.param.UserInfoParam;
import com.github.niefy.modules.wx.service.TemplateApiService;
import com.github.niefy.modules.wx.service.WechatUserInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api")
@Api(tags = {"对外API - 微信模板"})
@Slf4j
public class WxTemplateApi {

    @Autowired
    private TemplateApiService templateApiService;

    @Autowired
    private WechatUserInfoService wechatUserInfoService;

    @PostMapping("/getDeriveTemplate")
    @ApiOperation("获取模板列表")
    @Cacheable(value = "t-cache1")
    public Result<List<TemplateInfo>> getDeriveTemplate(@RequestBody TemplateSearchParam templateParam){
        log.info("请求获取模板列表参数：" + JSONObject.toJSONString(templateParam));
        return Result.ok(templateApiService.getDeriveTemplateList(templateParam));
    }

/*    @PostMapping("/sendWechatMsg")
    @ApiOperation("发送单条模板消息")
    public Result sendWechatMsg(@RequestBody @Valid TemplateMsgParam templateMsgParam){
        log.info("请求发送模板消息参数：" + JSONObject.toJSONString(templateMsgParam));
        return templateApiService.sendTemplateMsg(templateMsgParam);
    }*/

    @GetMapping("/getStatus")
    @ApiOperation("查看发送消息的状态")
    @ApiImplicitParam(name = "msgId", value = "消息id", required = true)
    public Result<TemplateMsgStatus> getStatus(@RequestParam("msgId") String msgId){
        if (!StringUtils.hasText(msgId)){
            return Result.error("msgId不能为空");
        }
        log.info("请求获取模板消息状态参数：" + msgId);
        return Result.ok(templateApiService.getTemplateMsgStatus(msgId));
    }

    @PostMapping("/sendWechatMsgWithDeriveId")
    @ApiOperation("发送衍生模板消息")
    public Result<TemplateMsgResult> sendWechatMsgWithDeriveId(@RequestBody @Valid BusinessMsgParam businessMsg){
        log.info("请求发送衍生模板消息参数：" + JSONObject.toJSONString(businessMsg));
        return templateApiService.sendWechatMsgWithDeriveId(businessMsg);
    }


    @PostMapping("/batchSendWechatMsgWithDeriveId")
    @ApiOperation("批量发送衍生模板消息")
    public Result<BatchTemplateMsgResult> batchSendWechatMsgWithDeriveId(@RequestBody @Valid BatchBusinessMsgParam businessMsg){
        log.info("请求发送衍生模板消息参数：" + JSONObject.toJSONString(businessMsg));
        return templateApiService.batchSendWechatMsgWithDeriveId(businessMsg);
    }


    @PostMapping("/findUserOpenId")
    @ApiOperation("获取用户openid")
    public Result<UserInfoDto> findUserInfo(@RequestBody UserInfoParam userInfoParam){
        return Result.ok(wechatUserInfoService.findByIdentity(userInfoParam));
    }

}
