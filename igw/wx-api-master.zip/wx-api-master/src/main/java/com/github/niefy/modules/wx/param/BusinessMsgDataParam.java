package com.github.niefy.modules.wx.param;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class BusinessMsgDataParam {

    @ApiModelProperty(value = "toUser即openId", required = true)
    @NotBlank(message = "openId不能为空")
    private String toUser;

    @ApiModelProperty(value = "待转换的数据", required = true)
    private JSONObject data;

    @ApiModelProperty(value = "跳转的链接", required = false)
    private String url;

}
