package com.github.niefy.modules.wx.enums;

public enum TemplateMsgStatusEnum {
    SUCCESS("success","消息发送成功"),
    FAIL( "fail","消息发送失败"),
    SENT( "sent","还未收到微信的响应");

    private String status;

    private String remark;

    TemplateMsgStatusEnum(String status, String remark){
        this.status = status;
        this.remark = remark;
    }

    public String getStatus() {
        return status;
    }
}
