package com.github.niefy.common.enums;

public interface IErrorCode {

    /**
     * 获取错误码
     * @return
     */
    Integer getCode();

    /**
     * 描述:得到错误消息
     **/
    String getMsg();

}
