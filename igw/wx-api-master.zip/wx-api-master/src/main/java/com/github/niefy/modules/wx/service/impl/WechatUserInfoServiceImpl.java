package com.github.niefy.modules.wx.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.github.niefy.common.exception.RRException;
import com.github.niefy.common.utils.BeanCopyUtils;
import com.github.niefy.modules.wx.dao.WechatUserInfoMapper;
import com.github.niefy.modules.wx.dto.UserInfoDto;
import com.github.niefy.modules.wx.entity.WechatUserInfo;
import com.github.niefy.modules.wx.param.UserInfoParam;
import com.github.niefy.modules.wx.service.WechatUserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Objects;

@Service
public class WechatUserInfoServiceImpl implements WechatUserInfoService {

    @Autowired
    private WechatUserInfoMapper wechatUserInfoMapper;

    @Override
    @DS("customer")
    public UserInfoDto findByIdentity(UserInfoParam userInfoParam) {

        boolean hasIdentityType = StringUtils.hasText(userInfoParam.getIdentityType());
        boolean hasIdentityId = StringUtils.hasText(userInfoParam.getIdentityId());
        boolean hasFundAccount = StringUtils.hasText(userInfoParam.getFundAcco());

        if (!hasFundAccount){
            if (!hasIdentityType && !hasIdentityId){
                throw new RRException("请输入参数");
            }
            if (!hasIdentityType || !hasIdentityId){
                throw new RRException("identityType,identityId两个参数必须同时存在");
            }
        }else {
            if (hasIdentityType || hasIdentityId){
                throw new RRException("fundAcco和identityType,identityId不能同时查询");
            }
        }

        WechatUserInfo wechatUserInfo = wechatUserInfoMapper.findByIdentity(BeanCopyUtils.copy(userInfoParam, WechatUserInfo.class));

        if (Objects.isNull(wechatUserInfo)){
            throw new RRException("找不到该用户的信息");
        }

        return BeanCopyUtils.copy(wechatUserInfo, UserInfoDto.class);
    }
}
