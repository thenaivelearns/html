package com.github.niefy.modules.wx.dto;

import com.alibaba.fastjson.JSONArray;
import lombok.Data;

/**
 * 这里包含基础模板 衍生模板的信息
 */

@Data
public class TemplateInfo {

    private String appid;

    private String deriveTemplateId;

    private String baseTemplateId;

    private String content;

    private String url;

    private JSONArray replaceData;

    private String status;
}
