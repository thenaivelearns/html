package com.github.niefy.modules.wx.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.niefy.common.enums.StatusCodeEnum;
import com.github.niefy.common.exception.RRException;
import com.github.niefy.common.utils.BeanCopyUtils;
import com.github.niefy.common.utils.RegExpUtils;
import com.github.niefy.common.utils.Result;
import com.github.niefy.modules.wx.dto.*;
import com.github.niefy.modules.wx.entity.BusinessTemplateRelation;
import com.github.niefy.modules.wx.entity.MsgTemplate;
import com.github.niefy.modules.wx.entity.TemplateMsgLog;
import com.github.niefy.modules.wx.entity.WxWhitelist;
import com.github.niefy.modules.wx.param.*;
import com.github.niefy.modules.wx.service.*;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.mp.bean.template.WxMpTemplateData;
import me.chanjar.weixin.mp.bean.template.WxMpTemplateMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TemplateApiServiceImpl implements TemplateApiService {

    @Autowired
    private TemplateMsgService templateMsgService;

    @Autowired
    private TemplateMsgLogService templateMsgLogService;

    @Autowired
    private MsgTemplateService msgTemplateService;

    @Autowired
    private BusinessTemplateRelationService businessTemplateRelationService;

    @Autowired
    private WxWhitelistService wxWhitelistService;

    @Autowired
    private DeriveTemplateService deriveTemplateService;

    @Override
    public List<TemplateInfo> getDeriveTemplateList(TemplateSearchParam templateParam) {
        return deriveTemplateService.getDeriveTemplate(templateParam);
    }

    @Override
    public Result sendTemplateMsg(TemplateMsgParam templateMsgParam) {
        //根据appid templateId找到模板
        String appid = templateMsgParam.getAppid();
        String templateId = templateMsgParam.getTemplateId();
        List<TemplateParamData> data = templateMsgParam.getData();

        MsgTemplate msgTemplate = msgTemplateService.getSingleTemplate(appid, templateId);

        if (Objects.nonNull(msgTemplate)){
            templateMsgParam.setTemplateId(msgTemplate.getTemplateId());
            JSONArray json = msgTemplate.getData();

            //这里取出用户在通道中定义的remark first param
            List<TemplateParamData> baseTemplateData = json.toJavaList(TemplateParamData.class);

            // 这里是对remark字段的覆盖规则 接口调用方传过来的优先级最高
            if (!CollectionUtils.isEmpty(data)){
                Map<String, TemplateParamData> requestData = data.stream().collect(Collectors.toMap(TemplateParamData::getName, Function.identity(),(t1, t2)->t2));
                if (!CollectionUtils.isEmpty(baseTemplateData)){
                    //取出接口调用方没有传 但是数据库有的字段
                    List<TemplateParamData> remainList = baseTemplateData.stream().filter(s-> Objects.isNull(requestData.get(s.getName()))).collect(Collectors.toList());
                    data.addAll(remainList);
                    templateMsgParam.setData(data);
                }
            }
        }else {
            log.error("找不到此参数对应的模板："+ JSONObject.toJSONString(templateMsgParam));
            return Result.error("找不到对应的模板");
        }

        WxMpTemplateMessage wxMpTemplateMessage = convert2WxTemplate(templateMsgParam);

        return templateMsgService.syncSendTemplateMsg(wxMpTemplateMessage, appid);
    }

    @Override
    public TemplateMsgStatus getTemplateMsgStatus(String msgId) {
        TemplateMsgLog templateMsgLog = templateMsgLogService.getStatusByMsgId(msgId);
        if (Objects.isNull(templateMsgLog)){
            throw new RRException("找不到和此msgId对应的消息");
        }

        String status = templateMsgLog.getStatus();

        TemplateMsgStatus statusDto = TemplateMsgStatus.builder()
                .status(status)
                .msgId(templateMsgLog.getMsgId())
                .build();
        return statusDto;
    }

    @Override
    public Result<TemplateMsgResult> sendWechatMsgWithDeriveId(BusinessMsgParam businessMsgParam) {
        BusinessMsgDataParam param = businessMsgParam.getParam();
        if (!StringUtils.hasText(param.getToUser())){
            throw new RRException("toUser不能为空");
        }
        if (StringUtils.hasText(param.getUrl()) && !RegExpUtils.isIllegalUrl(param.getUrl())){
            throw new RRException("请输入合法的url");
        }
        //白名单过滤
        List<BusinessMsgDataParam> params = this.filterWhitelistOpenId(businessMsgParam.getApi(), businessMsgParam.getRefSysId(), Collections.singletonList(param));
        //如果params是空的 说明没有在白名单内 直接return
        if (CollectionUtils.isEmpty(params)){
            return Result.error("该openid不在灰度验证范围内，不允许发送");
        }

        String toUser = param.getToUser();
        String url = param.getUrl();
        JSONObject source = param.getData();
        Result<TemplateMsgResult> result;

        //配置表查找映射关系
        BusinessTemplateRelation config = businessTemplateRelationService.findConfig(businessMsgParam.getApi(), businessMsgParam.getRefSysId());

        if (Objects.nonNull(config)){

            //查询衍生模板信息
            TemplateInfo templateInfo = deriveTemplateService.findByDeriveTemplateId(config.getDeriveTemplateId());
            //将配置表格式的数据转为微信模板所需要的格式
            List<WxMpTemplateData> dataList = this.businessDataConvert2TemplateMsg(config.getMapping(), source, templateInfo.getReplaceData());
            url = StringUtils.hasText(url)? url : templateInfo.getUrl();

            //组装发送数据
            WxMpTemplateMessage wxMpTemplateMessage = WxMpTemplateMessage.builder()
                    .templateId(templateInfo.getBaseTemplateId())
                    .toUser(toUser)
                    .url(url)
                    .data(dataList)
                    .build();

            result = templateMsgService.syncSendTemplateMsg(wxMpTemplateMessage, templateInfo.getAppid());

        }else{
            throw new RRException("找不到对应的配置，请联系管理员");
        }

        return result;
    }

    @Override
    public Result<BatchTemplateMsgResult> batchSendWechatMsgWithDeriveId(BatchBusinessMsgParam businessMsgParam) {

        BatchTemplateMsgResult templateMsgResult = new BatchTemplateMsgResult();
        List<TemplateMsgResult> successList = new ArrayList<>();
        List<String> failList = new ArrayList<>();

        //配置表查找映射关系
        BusinessTemplateRelation config = businessTemplateRelationService.findConfig(businessMsgParam.getApi(), businessMsgParam.getRefSysId());

        if (Objects.nonNull(config)){

            List<BusinessMsgDataParam> params = businessMsgParam.getParams();
            //白名单过滤
            params = this.filterWhitelistOpenId(businessMsgParam.getApi(), businessMsgParam.getRefSysId(), params);
            //如果params是空的 说明没有在白名单内 直接return
            if (CollectionUtils.isEmpty(params)){
                return Result.error("该openid不在灰度验证范围内，不允许发送");
            }

            JSONObject mappingRelation = config.getMapping();
            //查询衍生模板信息
            TemplateInfo templateInfo = deriveTemplateService.findByDeriveTemplateId(config.getDeriveTemplateId());

            for (BusinessMsgDataParam param : params) {
                String toUser = param.getToUser();
                JSONObject source = param.getData();

                if (StringUtils.hasText(toUser)){

                    try{
                        //把配置表的映射关系转化为微信模板需要的格式
                        List<WxMpTemplateData> dataList = this.businessDataConvert2TemplateMsg(mappingRelation, source, templateInfo.getReplaceData());
                        String url = StringUtils.hasText(param.getUrl())? param.getUrl() : templateInfo.getUrl();

                        WxMpTemplateMessage wxMpTemplateMessage = WxMpTemplateMessage.builder()
                                .templateId(templateInfo.getBaseTemplateId())
                                .toUser(toUser)
                                .url(url)
                                .data(dataList)
                                .build();

                        Result<TemplateMsgResult> result = templateMsgService.syncSendTemplateMsg(wxMpTemplateMessage, templateInfo.getAppid());

                        if (result.getCode().equals(StatusCodeEnum.SUCCESS.getCode())){
                            successList.add(result.getData());
                        }else {
                            failList.add(param.getToUser());
                        }
                    }catch (RRException r){
                        log.error(r.getMsg());
                        failList.add(param.getToUser());
                    } catch (Exception e){
                        log.error("发生异常"+ e.getMessage());
                        failList.add(param.getToUser());
                    }
                }

            }

        }else{
            throw new RRException("找不到对应的配置，请联系管理员");
        }
        templateMsgResult.setSuccessList(successList);
        templateMsgResult.setFailList(failList);
        return Result.ok(templateMsgResult);
    }

    //开启白名单开关时 过滤掉没在白名单表的openid 只返回在白名单里面的openid
    private List<BusinessMsgDataParam> filterWhitelistOpenId(String api, String refSysId, List<BusinessMsgDataParam> params){
        //去白名单表查询是否有这样的记录
        List<WxWhitelist> list = wxWhitelistService.findWhitelist(api, refSysId);

        //如果有 则判断每次发送的openid 是否在白名单中 在的话只发送给白名单的人 没有的话就不处理
        if (!CollectionUtils.isEmpty(list)){
            List<String> whiteListOpenIds = list.stream().map(WxWhitelist::getOpenId).collect(Collectors.toList());
            params = params.stream().filter(s -> whiteListOpenIds.contains(s.getToUser())).collect(Collectors.toList());
        }

        return params;
    }

    /**
     * 将交易类数据的参数拼接上衍生模板的保底内容 最后转化为微信官方要求格式的数据
     * @throws RRException
     * @Param source 源数据 即接口调用方传过来的数据 例子 {"v_requestDate": "2022-06-26"}
     * @Param mapping 配置表配置的映射关系 {"v_requestDate": "serviceDate"}
     * @Param replaceData 衍生模板配置的保底数据 [{"name": "remark",value:"is remark",color:"#ffffff"},{"name":"serviceDate","color":"#ffffff"}]
     * @return [{"name": "remark",value:"is remark",color:"#ffffff"},{"name": "serviceDate",value:"2022-06-26", "color":"#ffffff"}}]
     */
    private List<WxMpTemplateData> businessDataConvert2TemplateMsg(JSONObject mapping, JSONObject source, JSONArray replaceData){

        Map<String, WxMpTemplateData> resultMap = new HashMap<>();
        //得到映射过来的数据 按照微信格式拼接
        for (String key : mapping.keySet()) {
            //先做source的验证 确保mapping里面配置的数据 source里面一定有
            if (!StringUtils.hasText(source.getString(key))){
                throw new RRException("param中的参数与配置表的参数不匹配,参数："+JSONObject.toJSONString(source));
            }
            WxMpTemplateData wxMpTemplateData = new WxMpTemplateData();
            wxMpTemplateData.setName(mapping.getString(key));
            wxMpTemplateData.setValue(source.getString(key));
            resultMap.put(mapping.getString(key), wxMpTemplateData);
        }

        if (!CollectionUtils.isEmpty(replaceData)){

            List<WxMpTemplateData> replaceDataList = replaceData.toJavaList(WxMpTemplateData.class);

            for (WxMpTemplateData replace : replaceDataList) {
                //如果衍生模板的保底内容 即replaceData 定义了 接口调用方没有传的数据 我们就加上
                //例如保底内容定义了remark 而接口调用方没有传 我们就加上remark
                //
                String nameKey = replace.getName();
                if (Objects.isNull(resultMap.get(nameKey))){
                    //这里是放replaceData有但是mapping里面没有的  例如remark字段
                    resultMap.put(replace.getName(), replace);
                }else {
                    //这里是补充color字段 value字段
                    WxMpTemplateData originData = resultMap.get(nameKey);
                    if (!StringUtils.hasText(originData.getColor())){
                        originData.setColor(replace.getColor());
                    }
                    if (!StringUtils.hasText(originData.getValue())){
                        originData.setValue(replace.getValue());
                    }
                    resultMap.put(nameKey, originData);
                }
            }
        }

        return  new ArrayList<>(resultMap.values());
    }


    //将开放接口入参 转化成 微信模板 标准的对象
    private WxMpTemplateMessage convert2WxTemplate(TemplateMsgParam param){

        WxMpTemplateMessage templateMessage = WxMpTemplateMessage.builder().
                templateId(param.getTemplateId())
                .toUser(param.getToUser())
                .url(param.getUrl())
                .build();

        if (!CollectionUtils.isEmpty(param.getData())){
            List<WxMpTemplateData> data = new ArrayList<>();
            for (TemplateParamData paramData: param.getData()) {
                WxMpTemplateData wxMpTemplateData = BeanCopyUtils.copy(paramData, WxMpTemplateData.class);
                data.add(wxMpTemplateData);
            }
            templateMessage.setData(data);
        }
        return templateMessage;
    }
}
