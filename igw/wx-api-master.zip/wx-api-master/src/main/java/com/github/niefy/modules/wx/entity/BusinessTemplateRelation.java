package com.github.niefy.modules.wx.entity;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BusinessTemplateRelation extends BaseEntity{

    @TableId(type = IdType.AUTO)
    private Long id;

    private String deriveTemplateId;

    private String api;

    private String refSysId;

    private JSONObject mapping;
}
