package com.github.niefy.modules.wx.service.impl;

import com.github.niefy.modules.wx.dao.BusinessTemplateRelationMapper;
import com.github.niefy.modules.wx.entity.BusinessTemplateRelation;
import com.github.niefy.modules.wx.service.BusinessTemplateRelationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BusinessTemplateRelationServiceImpl implements BusinessTemplateRelationService {

    @Autowired
    private BusinessTemplateRelationMapper businessTemplateRelationMapper;

    @Override
    public BusinessTemplateRelation findConfig(String api, String refSysId) {
        return businessTemplateRelationMapper.findConfig(api, refSysId);
    }
}
