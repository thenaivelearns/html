package com.github.niefy.modules.wx.param;

import com.github.niefy.modules.wx.dto.TemplateParamData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@ApiModel("模板消息参数")
public class TemplateMsgParam {

    @NotBlank(message = "appid不能为空")
    @ApiModelProperty(value = "appid", required = true)
    private String appid;

    @NotBlank(message = "toUser不能为空")
    @ApiModelProperty(value = "toUser即openId", required = true)
    private String toUser;

    @NotBlank(message = "templateId不能为空")
    @ApiModelProperty(value = "模板id", required = true)
    private String templateId;

    @ApiModelProperty(value = "点击模板消息跳转的url", required = false)
    private String url;

    @NotEmpty(message = "数据不能为空")
    @ApiModelProperty(value = "模板填充的数据", required = false)
    private List<TemplateParamData> data;
}
