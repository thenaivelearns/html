package com.github.niefy.common.utils;

import com.github.niefy.common.enums.StatusCodeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Result<T> implements Serializable {


    private static final long serialVersionUID = -7203083949399598804L;

    private Integer code;

    private String msg;

    private T data;

/*    public Result(Integer code, String msg, T data) {
        this.code = code;
        this.data = data;
        this.msg = msg;
    }

    public Result(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Result(){}*/



    public static <T> Result<T> ok() {
        Result<T> result = new Result<>();
        result.setCode(StatusCodeEnum.SUCCESS.getCode());
        result.setMsg(StatusCodeEnum.SUCCESS.getMsg());
        return result;
    }



    public static <T> Result<T> ok(T data) {
        Result<T> result = new Result<>();
        result.setCode(StatusCodeEnum.SUCCESS.getCode());
        result.setMsg(StatusCodeEnum.SUCCESS.getMsg());
        result.setData(data);
        return result;
    }

    public static <T> Result<T> error(String message) {
        Result<T> result = new Result<>();
        result.setCode(StatusCodeEnum.FAIL.getCode());
        result.setMsg(message);
        return result;
    }

    public static <T> Result<T> error(Integer code, String message) {
        Result<T> result = new Result<>();
        result.setCode(code);
        result.setMsg(message);
        return result;
    }

    @Override
    public String toString() {
        return "Result [code=" + code + ", data=" + data + ", msg=" + msg + "]";
    }

}
