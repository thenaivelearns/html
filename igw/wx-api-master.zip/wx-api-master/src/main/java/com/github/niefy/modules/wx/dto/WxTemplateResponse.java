package com.github.niefy.modules.wx.dto;

import lombok.Data;

/**
 * 微信回调消息结果数据
 */
@Data
public class WxTemplateResponse {

    private String toUser;

    private String fromUser;

    private Long createTime;

    private String msgType;

    private String event;

    private Long msgId;

    private String status;
}
