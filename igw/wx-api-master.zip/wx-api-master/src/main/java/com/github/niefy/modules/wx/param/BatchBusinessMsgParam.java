package com.github.niefy.modules.wx.param;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class BatchBusinessMsgParam {

    /*    @NotBlank(message = "deriveTemplateId不能为空")
    @ApiModelProperty(value = "衍生模板模板id", required = true)
    private String deriveTemplateId;*/

    @NotBlank(message = "api不能为空")
    @ApiModelProperty(value = "api", required = true)
    private String api;

    @NotBlank(message = "refSysId不能为空")
    @ApiModelProperty(value = "refSysId", required = true)
    private String refSysId;

    @NotEmpty
    @Size(max = 200, message = "最大发送对象为200个")
    private List<BusinessMsgDataParam> params;

/*    @NotBlank(message = "toUser不能为空")
    @ApiModelProperty(value = "toUser即openId", required = true)
    private String toUser;

    @NotNull(message = "消息数据不能为空")
    @ApiModelProperty(value = "待转换的数据", required = true)
    private JSONObject data;*/

}
