package com.github.niefy.modules.wx.constants;

public class PageSizeConstant {
    /**
     * 默认分页大小
     */
    public static final int PAGE_SIZE_SMALL = 20;
    public static final int PAGE_SIZE_MEDIUM = 50;
}
