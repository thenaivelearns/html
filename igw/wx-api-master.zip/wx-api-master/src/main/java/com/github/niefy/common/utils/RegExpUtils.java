package com.github.niefy.common.utils;

public class RegExpUtils {

    public static final String URL_REG = "^(?=^.{3,255}$)(http(s)?:\\/\\/)?(www\\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\\d+)*(\\/\\w+\\.\\w+)*([\\?&]\\w+=\\w*)*$";

    public static boolean isIllegalUrl(String url){
        return url.matches(URL_REG);
    }

    public static void main(String[] args) {
        System.out.println(isIllegalUrl("baidu.com"));
        System.out.println(isIllegalUrl("https://baidu.com"));
        System.out.println(isIllegalUrl("http://baidu.com"));
        System.out.println(isIllegalUrl("http://baidu.com?a=1"));
        System.out.println(isIllegalUrl("http://baidu.com>1=1"));
        System.out.println(isIllegalUrl("http://baidu"));
        System.out.println(isIllegalUrl("www.baidu.com"));
        System.out.println(isIllegalUrl("http://www"));
        System.out.println(isIllegalUrl("123131"));

    }
}
