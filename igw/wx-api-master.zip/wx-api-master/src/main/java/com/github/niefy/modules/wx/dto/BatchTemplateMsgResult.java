package com.github.niefy.modules.wx.dto;

import lombok.Data;

import java.util.List;

@Data
public class BatchTemplateMsgResult {

    private List<TemplateMsgResult> successList;

    private List<String> failList;

}
