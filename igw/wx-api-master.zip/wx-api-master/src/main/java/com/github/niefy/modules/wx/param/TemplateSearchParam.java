package com.github.niefy.modules.wx.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 模板查询条件参数
 */
@Data
@AllArgsConstructor
@ApiModel("模板查询条件参数")
public class TemplateSearchParam {

    @ApiModelProperty(value = "appid", notes = "微信公众号id", required = false)
    private String appid;

    @ApiModelProperty(value = "模板id", notes = "模板id", required = false)
    private String deriveTemplateId;
}
