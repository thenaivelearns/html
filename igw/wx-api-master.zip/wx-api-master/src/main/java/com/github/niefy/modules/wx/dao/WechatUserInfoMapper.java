package com.github.niefy.modules.wx.dao;

import com.github.niefy.modules.wx.entity.WechatUserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface WechatUserInfoMapper {

    WechatUserInfo findByIdentity(@Param("wechatUserInfo") WechatUserInfo wechatUserInfo);

}
