package com.github.niefy.modules.wx.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 用户查询条件参数
 */

@Data
@ApiModel("用户查询条件参数")
public class UserInfoParam {

    @ApiModelProperty("证件类型")
    private String identityType;

    @ApiModelProperty("证件号")
    private String identityId;

    @ApiModelProperty("基金账户")
    private String fundAcco;
}
