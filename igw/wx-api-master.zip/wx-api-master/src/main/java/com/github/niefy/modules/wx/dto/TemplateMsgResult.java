package com.github.niefy.modules.wx.dto;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class TemplateMsgResult {

    private String msgId;

    private String toUser;

}
