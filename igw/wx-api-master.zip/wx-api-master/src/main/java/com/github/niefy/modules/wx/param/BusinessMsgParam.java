package com.github.niefy.modules.wx.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@ApiModel("交易类模板消息需要的参数")
public class BusinessMsgParam {

/*    @NotBlank(message = "deriveTemplateId不能为空")
    @ApiModelProperty(value = "衍生模板模板id", required = true)
    private String deriveTemplateId;*/

    @NotBlank(message = "api不能为空")
    @ApiModelProperty(value = "api", required = true)
    private String api;

    @NotBlank(message = "refSysId不能为空")
    @ApiModelProperty(value = "refSysId", required = true)
    private String refSysId;

    @NotNull
    private BusinessMsgDataParam param;

/*    @NotBlank(message = "toUser不能为空")
    @ApiModelProperty(value = "toUser即openId", required = true)
    private String toUser;

    @NotNull(message = "消息数据不能为空")
    @ApiModelProperty(value = "待转换的数据", required = true)
    private JSONObject data;*/
}
