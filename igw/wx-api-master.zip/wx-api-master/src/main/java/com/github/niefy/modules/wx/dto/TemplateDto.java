package com.github.niefy.modules.wx.dto;

import com.github.niefy.common.utils.Json;
import lombok.Data;

/**
 *
 */

@Data
public class TemplateDto {

    private String appid;

    private String templateId;

    private String name;

    private String title;

    private String content;

    //private JSONArray data;

    @Override
    public String toString() {
        return Json.toJsonString(this);
    }
}
