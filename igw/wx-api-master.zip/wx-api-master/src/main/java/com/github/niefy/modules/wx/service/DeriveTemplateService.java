package com.github.niefy.modules.wx.service;

import com.github.niefy.modules.wx.dto.TemplateInfo;
import com.github.niefy.modules.wx.param.TemplateSearchParam;

import java.util.List;

public interface DeriveTemplateService {

    TemplateInfo findByDeriveTemplateId(String deriveTemplateId);


    /**
     * 根据查询条件获取模板列表
     * @param templateParam
     * @return
     */
    List<TemplateInfo> getDeriveTemplate(TemplateSearchParam templateParam);

}
