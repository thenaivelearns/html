package com.github.niefy.common.utils;

import com.github.niefy.common.enums.StatusCodeEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * 返回数据
 * @author Mark sunlightcs@gmail.com
 */
public class R extends HashMap<String, Object> {
    private static final long serialVersionUID = 1L;

    public R() {
        put("code", StatusCodeEnum.SUCCESS.getCode());
        put("msg", StatusCodeEnum.SUCCESS.getMsg());
    }

    public static R error() {
        return error(StatusCodeEnum.FAIL.getCode(), "未知异常，请联系管理员");
    }

    public static R error(String msg) {
        return error(StatusCodeEnum.FAIL.getCode(), msg);
    }

    public static R error(int code, String msg) {
        R r = new R();
        r.put("code", code);
        r.put("msg", msg);
        return r;
    }

    public static R ok(String msg) {
        R r = new R();
        r.put("msg", msg);
        return r;
    }

    public static R ok(Map<String, Object> map) {
        R r = new R();
        r.putAll(map);
        return r;
    }

    public static R ok() {
        return new R();
    }

    @Override
    public R put(String key, Object value) {
        super.put(key, value);
        return this;
    }

    public R put(Object value) {
        super.put("data", value);
        return this;
    }
}
