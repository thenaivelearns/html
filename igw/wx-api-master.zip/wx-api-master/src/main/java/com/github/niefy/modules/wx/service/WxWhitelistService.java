package com.github.niefy.modules.wx.service;

import com.github.niefy.modules.wx.entity.WxWhitelist;

import java.util.List;

public interface WxWhitelistService {

    List<WxWhitelist> findWhitelist(String api, String refSysId);

}
