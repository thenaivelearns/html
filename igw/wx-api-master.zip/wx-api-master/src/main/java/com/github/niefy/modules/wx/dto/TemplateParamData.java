package com.github.niefy.modules.wx.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 调用方自定义传的模板数据
 */

@Data
public class TemplateParamData implements Serializable {

    private static final long serialVersionUID = 6301535292940277870L;

    private String name;
    private String value;
    private String color;

}
