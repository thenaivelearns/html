package com.github.niefy.modules.wx.dao;

import com.github.niefy.modules.wx.entity.BusinessTemplateRelation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface BusinessTemplateRelationMapper {

    BusinessTemplateRelation findConfig(@Param("api") String api, @Param("refSysId") String refSysId);
}
