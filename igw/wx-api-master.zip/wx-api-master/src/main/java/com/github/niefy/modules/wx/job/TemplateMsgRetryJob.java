package com.github.niefy.modules.wx.job;

import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class TemplateMsgRetryJob {

    @XxlJob("templateMsgRetryHandler")
    public void templateMsgRetryHandler(){
        log.info("定时重试发送模板消息任务启动");
        //todo 重试job
        log.info("定时重试发送模板消息任务结束");
    }

}
