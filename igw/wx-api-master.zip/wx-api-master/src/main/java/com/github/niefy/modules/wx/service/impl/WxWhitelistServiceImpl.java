package com.github.niefy.modules.wx.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.niefy.modules.wx.dao.WxWhitelistMapper;
import com.github.niefy.modules.wx.entity.WxWhitelist;
import com.github.niefy.modules.wx.service.WxWhitelistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WxWhitelistServiceImpl implements WxWhitelistService {

    @Autowired
    private WxWhitelistMapper wxWhitelistMapper;

    @Override
    public List<WxWhitelist> findWhitelist(String api, String refSysId) {

        return wxWhitelistMapper.selectList(
                new QueryWrapper<WxWhitelist>().eq("ref_sys_id", refSysId)
                        .eq("api", api)
                        //.in("open_id", openIds)
        );

    }
}
