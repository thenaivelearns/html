package com.github.niefy.modules.wx.service;

import com.github.niefy.modules.wx.entity.BusinessTemplateRelation;

public interface BusinessTemplateRelationService {

    BusinessTemplateRelation findConfig(String api, String refSysId);

}
