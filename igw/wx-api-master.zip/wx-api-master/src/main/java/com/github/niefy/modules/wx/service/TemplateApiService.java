package com.github.niefy.modules.wx.service;

import com.github.niefy.common.utils.Result;
import com.github.niefy.modules.wx.dto.BatchTemplateMsgResult;
import com.github.niefy.modules.wx.dto.TemplateInfo;
import com.github.niefy.modules.wx.dto.TemplateMsgResult;
import com.github.niefy.modules.wx.dto.TemplateMsgStatus;
import com.github.niefy.modules.wx.param.BatchBusinessMsgParam;
import com.github.niefy.modules.wx.param.BusinessMsgParam;
import com.github.niefy.modules.wx.param.TemplateMsgParam;
import com.github.niefy.modules.wx.param.TemplateSearchParam;

import java.util.List;

public interface TemplateApiService {


    /**
     * 根据条件查询模板列表
     * @return
     */
    List<TemplateInfo> getDeriveTemplateList(TemplateSearchParam templateParam);

    /**
     * 发送单挑模板消息
     * @param templateMsgParam
     * @return
     */
    Result sendTemplateMsg(TemplateMsgParam templateMsgParam);

    /**
     * 根据msgId获取消息状态
     * @param msgId
     * @return
     */
    TemplateMsgStatus getTemplateMsgStatus(String msgId);

    /**
     * 发送交易类衍生模板消息
     * @param businessMsgParam
     * @return
     */
    Result<TemplateMsgResult> sendWechatMsgWithDeriveId(BusinessMsgParam businessMsgParam);

    /**
     * 批量发送交易类衍生模板消息
     * @param businessMsgParam
     * @return
     */
    Result<BatchTemplateMsgResult> batchSendWechatMsgWithDeriveId(BatchBusinessMsgParam businessMsgParam);
}
