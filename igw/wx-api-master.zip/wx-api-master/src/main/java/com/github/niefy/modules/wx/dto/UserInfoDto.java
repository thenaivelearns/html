package com.github.niefy.modules.wx.dto;

import lombok.Data;

@Data
public class UserInfoDto {

    private String openId;

}
