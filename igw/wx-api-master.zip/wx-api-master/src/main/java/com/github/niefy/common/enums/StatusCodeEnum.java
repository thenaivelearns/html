package com.github.niefy.common.enums;

public enum StatusCodeEnum implements IErrorCode{

    SUCCESS(10000, "success"),
    FAIL(40000, "fail")
    ;

    private Integer code;

    private String msg;


    StatusCodeEnum(Integer code,String message){
        this.code=code;
        this.msg=message;
    }

    @Override
    public Integer getCode() {
        return this.code;
    }

    @Override
    public String getMsg() {
        return this.msg;
    }
}
