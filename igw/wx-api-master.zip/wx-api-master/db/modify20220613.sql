--发送日志表增加字段
ALTER table wx_template_msg_log add column response varchar(500) comment '微信响应结果';
ALTER table wx_template_msg_log add column status varchar(32) not null default 'unknown' comment '消息发送状态';
ALTER table wx_template_msg_log add column msg_id varchar(32) comment '微信返回的msgId';

DROP TABLE IF EXISTS `wx_derive_template`;
CREATE TABLE `wx_derive_template`  (
  `id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `template_id` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '公众号模板ID',
  `base_template` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '基准模板id',
  `template_name` varchar(50) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '模版名称',
  `replace_data` json NULL COMMENT '保底替换内容',
  `url` varchar(255) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '链接',
  `status` tinyint(1) UNSIGNED NOT NULL COMMENT '是否有效',
  `create_user` varchar(50) CHARACTER SET utf8 COMMENT '创建人',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_user` varchar(50) CHARACTER SET utf8 COMMENT '修改人',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_template_id`(`template_id`) USING BTREE COMMENT '模板id',
  INDEX `idx_status`(`status`) USING BTREE COMMENT '模板状态'
  ) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COMMENT = '衍生消息模板' ROW_FORMAT = Dynamic;

--业务与模板映射信息表
DROP TABLE IF EXISTS `business_template_relation`;
CREATE TABLE `business_template_relation`  (
  `id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `api` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT 'api接口',
  `ref_sys_id` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT 'api接口',
  `derive_template_id` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '衍生模板id',
  `mapping` json NULL COMMENT '映射关系',
  `create_user` varchar(50) CHARACTER SET utf8 COMMENT '创建人',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_user` varchar(50) CHARACTER SET utf8 COMMENT '修改人',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_sys_api`(`api`,`ref_sys_id`) USING BTREE COMMENT '外部系统唯一API'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COMMENT = '业务与模板映射信息表' ROW_FORMAT = Dynamic;

--白名单表
DROP TABLE IF EXISTS `wx_whitelist`;
CREATE TABLE `wx_whitelist`  (
  `id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id',
  `api` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT 'api接口',
  `ref_sys_id` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT 'api接口',
  `open_id` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '用户openid',
  `remark` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '备注',
  `create_user` varchar(50) CHARACTER SET utf8 COMMENT '创建人',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_user` varchar(50) CHARACTER SET utf8 COMMENT '修改人',
  `update_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_sys_api`(`api`,`ref_sys_id`) USING BTREE COMMENT '外部系统唯一API'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COMMENT = '微信白名单表' ROW_FORMAT = Dynamic;