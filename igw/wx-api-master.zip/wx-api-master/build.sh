#cd $GITPATH
#gradle build
gradle clean bootJar --stacktrace  --info
